USB Cable Reel by Manabun_Lab on Thingiverse: https://www.thingiverse.com/thing:2856991

Summary:
The latest version of USB Cable Reel v2.0 is available here:https://makerworld.com/en/models/553595A tip as appreciation is welcome. I created it to organize the USB cable on the desk.Please print out and combine the three parts.There are small and large size, small is 0.5 to 1 meter cable, large is 1.5 to 2 meter cable.(The length depends on the thickness of the cable.)Please enjoy!USB Cable Holder is herehttps://www.thingiverse.com/thing:2960427
